define([], function() {
    return window.emojione;
});