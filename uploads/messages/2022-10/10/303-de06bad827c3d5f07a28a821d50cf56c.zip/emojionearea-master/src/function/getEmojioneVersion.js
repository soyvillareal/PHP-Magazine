define([], function() {
    return function() {
        return window.emojioneVersion || '3.1.2';
    };
});