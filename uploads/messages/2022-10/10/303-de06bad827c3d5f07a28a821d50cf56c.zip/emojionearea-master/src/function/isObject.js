define(function() {
    return function(variable) {
        return typeof variable === 'object';
    };
});